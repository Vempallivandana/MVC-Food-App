package com.jsp.foodapp.dao;

public class ItemDao {

}
